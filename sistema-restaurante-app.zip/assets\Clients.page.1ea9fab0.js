import{m as a,F as t,aE as e,aC as r}from"./index.163e93a7.js";const s=()=>a(t,{children:a(e,{maxWidth:"lg",children:a(r,{})})});export{s as default};

import{m as a,aE as t,aC as e}from"./index.163e93a7.js";const s=()=>a(t,{maxWidth:"lg",children:a(e,{})});export{s as default};

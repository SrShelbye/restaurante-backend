import{m as t,F as a,aC as r}from"./index.163e93a7.js";const e=()=>t(a,{children:t(r,{})});export{e as default};

import{m as a,aE as r,aC as t}from"./index.163e93a7.js";const s=()=>a("div",{children:a(r,{maxWidth:"lg",children:a(t,{})})});export{s as default};

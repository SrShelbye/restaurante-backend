import{aF as e,m as a,F as t,aE as s,aC as r}from"./index.163e93a7.js";const i=()=>(e(),a(t,{children:a(s,{maxWidth:"lg",children:a(r,{})})}));export{i as default};
